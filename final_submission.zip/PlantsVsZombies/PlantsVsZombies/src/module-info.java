module PlantsVsZombies {
    requires javafx.fxml;
    requires javafx.controls;
    requires javafx.media;
    opens sample;
}