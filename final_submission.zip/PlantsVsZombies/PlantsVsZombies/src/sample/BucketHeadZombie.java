package sample;

public class BucketHeadZombie extends Zombie{

    protected float Attack()
    {
        return 0;
    }

}
