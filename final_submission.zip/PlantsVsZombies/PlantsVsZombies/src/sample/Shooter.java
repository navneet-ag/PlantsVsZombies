package sample;

public class Shooter extends Plant{

    protected float ShootingPower;
    protected float Frequency;


    public float getShootingPower() {
        return ShootingPower;
    }

    public void setShootingPower(float shootingPower) {
        ShootingPower = shootingPower;
    }

    public float getFrequency() {
        return Frequency;
    }

    public void setFrequency(float frequency) {
        Frequency = frequency;
    }

    protected void Shoot()
    {

    }


}
