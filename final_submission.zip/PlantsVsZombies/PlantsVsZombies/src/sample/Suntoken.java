package sample;

public class Suntoken extends Plant{

    protected float SunValue;
    protected float RefruitTime;

    public float getSunValue() {
        return SunValue;
    }

    public void setSunValue(float sunValue) {
        SunValue = sunValue;
    }

    public float getRefruitTime() {
        return RefruitTime;
    }

    public void setRefruitTime(float refruitTime) {
        RefruitTime = refruitTime;
    }

    public void GiveSun()
    {

    }
}
