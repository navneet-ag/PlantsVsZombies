package sample;

import java.io.Serializable;

public class Tile implements Serializable {
}
