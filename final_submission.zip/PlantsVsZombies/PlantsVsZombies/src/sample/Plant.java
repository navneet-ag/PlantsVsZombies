package sample;

public class Plant extends Avatar {
//    protected String TileNumber

    protected void Die()
    {

    }

}
