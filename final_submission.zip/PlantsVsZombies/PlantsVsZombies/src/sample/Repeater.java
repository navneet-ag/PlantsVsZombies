package sample;

public class Repeater extends Shooter {

    public void Repeater()
    {

    }

    protected void Shoot()
    {


    }
}
