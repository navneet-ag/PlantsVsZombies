package sample;

public class Bomb extends Plant{
    protected float Impact;
    protected float ExplodeTime;

    public float getImpact() {
        return Impact;
    }

    public void setImpact(float impact) {
        Impact = impact;
    }

    public float getExplodeTime() {
        return ExplodeTime;
    }

    public void setExplodeTime(float explodeTime) {
        ExplodeTime = explodeTime;
    }

    protected void Explode()
    {

    }


}
