package sample;

import java.io.Serializable;

public class TwinSunflower implements Serializable {


    protected void GiveSun()
    {


    }
}
