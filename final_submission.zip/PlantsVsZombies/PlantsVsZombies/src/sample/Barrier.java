package sample;

public class Barrier extends Plant {
}
