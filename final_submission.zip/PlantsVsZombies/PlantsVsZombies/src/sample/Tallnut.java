package sample;

public class Tallnut extends Barrier{
}
