package sample;

public class Cherrybomb extends Bomb {

    protected void Explode()
    {

    }
}
